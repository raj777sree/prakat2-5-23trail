package com.prakat.employe.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prakat.employe.api.entity.Employee;
import com.prakat.employe.api.exception.EmployeeAlreadyExistsException;
import com.prakat.employe.api.exception.EmployeeNotFoundException;
import com.prakat.employe.api.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository empRepository;

	public String addemploye(Employee emp) throws EmployeeAlreadyExistsException {
		
		if(empRepository.existsByEmail(emp.getEmail())) {	
			 throw new EmployeeAlreadyExistsException("Employee Already Existed");
		}
		else {
			empRepository.save(emp);
			return "Employe Successfully Added";
		}
	}
	
 public List<Employee> getEmployes() {
        return empRepository.findAll();	
     }
      
     public String updateEmployee(long id ,Employee emp) {
        
    	 if(empRepository.existsById(id)) {
    		 
    		 Employee employee= empRepository.findById(id);
     		 employee.setFirstname(emp.getFirstname());
             employee.setLastname(emp.getLastname());
             employee.setEmail(emp.getEmail());
    		 empRepository.save(employee);
    		 
    		 return"Employee Successfully Updated";
    	 }
         return "Something Wrong";
   }
     
     public String deleteEmployee(long id) throws EmployeeNotFoundException{
    	
    	 if(empRepository.existsById(id)) {
    		 empRepository.deleteById(id);
    	      return "Successfully Deleted";
    	 }
    	 else {
    		 throw new EmployeeNotFoundException("Employe Not Found");
    	 }
    
	
  }

	public Employee LoginDetails(String email, String password) throws EmployeeNotFoundException{
		
		if(empRepository.existsByEmail(email)) {
			Employee employee = empRepository.findByEmailAndPassword(email, password);
			return employee;
		}
		throw new EmployeeNotFoundException("Email Not Found");
		
	}

	public Employee fetchByEmployee(long id) throws EmployeeNotFoundException {
	
		if(empRepository.existsById(id)) {
			return empRepository.findById(id);
			
		}
		else throw new EmployeeNotFoundException("Employee Not Found");
		
	}
}
