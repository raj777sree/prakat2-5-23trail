package com.prakat.employe.api.exception;

public class ErrorResponse {

	private String errorMessage;
	private String errorStatus;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorStatus() {
		return errorStatus;
	}
	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}
	public ErrorResponse() {
		super();
		
	}
	public ErrorResponse(String errorMessage, String errorStatus) {
		super();
		this.errorMessage = errorMessage;
		this.errorStatus = errorStatus;
	}


	
	
}
