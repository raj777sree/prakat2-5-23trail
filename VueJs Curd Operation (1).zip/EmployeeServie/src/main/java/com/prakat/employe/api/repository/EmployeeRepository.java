package com.prakat.employe.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.prakat.employe.api.entity.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

public 	boolean existsByEmail(String email);
public 	boolean existsByEmailAndPassword (String email, String password);
public	Employee  findById(long id);
public  Employee findByEmailAndPassword (String email, String password);
public	Employee findByEmail (String email);
	



   
}
