package com.prakat.employe.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class EmployeeServieApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeServieApplication.class, args);
	}

}
