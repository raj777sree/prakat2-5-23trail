package com.prakat.employe.api.exception;

import java.net.http.HttpRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;



@ControllerAdvice
public class EmployeGlobalException {
	
    @ExceptionHandler(value = EmployeeNotFoundException.class)
	ResponseEntity<ErrorResponse> handleOnEmployeeNotFound(EmployeeNotFoundException empNot){
		
    	ErrorResponse error = new ErrorResponse(empNot.getMessage(),"404");
    	
    	return new ResponseEntity(error,HttpStatus.NOT_FOUND);
		
	}



@ExceptionHandler(value = EmployeeAlreadyExistsException.class)
ResponseEntity<ErrorResponse> handleAlredyExists(EmployeeAlreadyExistsException empexist){
	
	ErrorResponse error = new ErrorResponse(empexist.getMessage(),"404");
	
	return new ResponseEntity(error,HttpStatus.BAD_REQUEST);
	
}
}