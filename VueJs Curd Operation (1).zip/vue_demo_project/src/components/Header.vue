<template>
 <span class="glyphicon glyphicon-envelope"></span>
</template>