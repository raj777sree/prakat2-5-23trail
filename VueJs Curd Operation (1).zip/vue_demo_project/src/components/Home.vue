<template>
 <span class="glyphicon glyphicon-envelope"></span>
<h1>
    Home Page
</h1>
</template>
