export default {
    setEmployeId(state, payload) { 
      state.EmployeId= payload.EmployeId;

    },
    setEmploye(state, payload) { 
        state.EmployeData = payload.EmployeData;
  
      },
  };