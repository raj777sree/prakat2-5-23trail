export default {
    employeId(state) {
      return state.EmployeId;
    },
    EmployeData(state){
        return state.EmployeData;
    }
  };