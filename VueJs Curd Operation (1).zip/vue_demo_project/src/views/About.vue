<template>
<h1>AboutPage</h1>
</template>
<style scoped>
h1{
    color: rgb(10, 5, 59);
    margin-left: 800px;
    margin-top: 30px;
}
</style>